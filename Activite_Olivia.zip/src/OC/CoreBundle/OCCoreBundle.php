<?php

namespace OC\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OCCoreBundle extends Bundle
{
}
